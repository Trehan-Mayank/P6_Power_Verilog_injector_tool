#!/usr/bin/env python3
"""
Power Verilog Parser
Parses .pv files with powermodule syntax and converts to standard Verilog.
"""

import re
import sys
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple


@dataclass
class Port:
    name: str
    direction: str
    is_supply: bool = False
    supply_type: Optional[str] = None


@dataclass
class Instance:
    instance_name: str = ""
    module_type: str = ""
    connections: Dict[str, str] = field(default_factory=dict)
    power_connections: Dict[str, str] = field(default_factory=dict)
    port_connections: Dict[str, str] = field(default_factory=dict)

    @property
    def module_name(self) -> str:
        return self.module_type


@dataclass
class Module:
    name: str
    is_powermodule: bool
    ports: List[Port] = field(default_factory=list)
    supply_ports: Dict[str, str] = field(default_factory=dict)
    instances: List[Instance] = field(default_factory=list)
    statements: List[str] = field(default_factory=list)


class PvParser:
    def __init__(self):
        self.modules: Dict[str, Module] = {}
        self.current_module: Optional[Module] = None

    def parse_file(self, filepath: str) -> Dict[str, Module]:
        with open(filepath, 'r') as f:
            content = f.read()

        content = self._remove_comments(content)
        self._parse_modules(content)

        return self.modules

    def _remove_comments(self, content: str) -> str:
        result = []
        for line in content.split('\n'):
            line = re.sub(r'//.*', '', line)
            result.append(line)
        return '\n'.join(result)

    def _parse_modules(self, content: str):
        powermodule_pattern = r'powermodule\s+(\w+)\s*\{'
        module_pattern = r'module\s+(\w+)\s*\('

        pos = 0
        while pos < len(content):
            pm_match = re.search(powermodule_pattern, content[pos:])
            mod_match = re.search(module_pattern, content[pos:])

            if pm_match and ((not mod_match) or pm_match.start() < mod_match.start()):
                header_end, end_pos = self._extract_powermodule_header(content, pos + pm_match.end() - 1)
                self._parse_powermodule(header_end, pm_match.group(1), end_pos)
                pos = end_pos
            elif mod_match:
                module_content, end_pos = self._extract_module(content, pos + mod_match.end() - 1)
                self._parse_module(module_content, mod_match.group(1))
                pos = end_pos
            else:
                pos += 1

    def _extract_powermodule_header(self, content: str, start: int) -> Tuple[str, int]:
        endpowermodule_pos = content.find('endpowermodule', start)
        if endpowermodule_pos == -1:
            endpowermodule_pos = len(content)
        return content[start:endpowermodule_pos], endpowermodule_pos + len('endpowermodule')

    def _extract_module(self, content: str, start: int) -> Tuple[str, int]:
        endmodule_pos = content.find('endmodule', start)
        if endmodule_pos == -1:
            return content[start:], len(content)
        return content[start:endmodule_pos], endmodule_pos + len('endmodule')

    def _parse_powermodule(self, header_content: str, name: str, body_end: int):
        module = Module(name=name, is_powermodule=True)

        port_section_match = re.search(r'\((.*?)\),\s*\((.*?)\)', header_content, re.DOTALL)
        if port_section_match:
            supply_part = port_section_match.group(1)
            port_part = port_section_match.group(2)

            for sup in supply_part.split(','):
                sup = sup.strip()
                if '->' in sup:
                    parts = sup.split('->')
                    port_name = parts[0].strip()
                    port_type = parts[1].strip()
                    module.supply_ports[port_name] = port_type
                    module.ports.append(Port(port_name, 'supply', is_supply=True, supply_type=port_type))

            for p in port_part.split(','):
                p = p.strip()
                if p.startswith('input '):
                    module.ports.append(Port(p.replace('input', '').strip(), 'input'))
                elif p.startswith('output '):
                    module.ports.append(Port(p.replace('output', '').strip(), 'output'))

        self._extract_instances_from_range(header_content, body_end, module)
        self._extract_statements_from_range(header_content, body_end, module)

        self.modules[name] = module

    def _parse_module(self, content: str, name: str):
        module = Module(name=name, is_powermodule=False)

        port_match = re.search(r'module\s+\w+\s*\((.*?)\);', content, re.DOTALL)
        if port_match:
            for p in port_match.group(1).split(','):
                p = p.strip()
                if p.startswith('input '):
                    module.ports.append(Port(p.replace('input', '').strip(), 'input'))
                elif p.startswith('output '):
                    module.ports.append(Port(p.replace('output', '').strip(), 'output'))

        self._extract_statements(content, module)

        self.modules[name] = module

    def _extract_instances_from_range(self, header_content: str, body_end: int, module: Module):
        endpowermodule_pos = header_content.find('endpowermodule')
        if endpowermodule_pos == -1:
            endpowermodule_pos = body_end

        body_start = header_content.find('};')
        if body_start != -1:
            body_start += 2
        else:
            body_start = len(header_content)

        body = header_content[body_start:endpowermodule_pos]
        combined = ' '.join(body.split())

        pattern1 = r'(?:(\w+)\s+)?(\w+)\s*\{([^}]+)\}\s*,\s*\{([^}]+)\}\s*;'
        for match in re.finditer(pattern1, combined):
            inst = Instance()
            group1 = match.group(1)
            group2_name = match.group(2)
            if group1:
                inst.module_type = group1
                inst.instance_name = group2_name
            else:
                # Extract module type from instance name (e.g., "leaf_inst1" -> "leaf")
                if '_' in group2_name:
                    parts = group2_name.rsplit('_', 1)
                    inst.module_type = parts[0]
                else:
                    inst.module_type = group2_name
                inst.instance_name = group2_name
            group3 = match.group(3)
            group4 = match.group(4)

            for pc in group3.split(','):
                m = re.search(r'\.(\w+)\s*\(([^)]+)\)', pc)
                if m:
                    inst.power_connections[m.group(1)] = m.group(2).strip()
            for c in group4.split(','):
                m = re.search(r'\.(\w+)\s*\((.+?)\)', c)
                if m:
                    inst.connections[m.group(1)] = m.group(2).strip()

            module.instances.append(inst)

        pattern2 = r'(?:(\w+)\s+)?(\w+)\s*\(((?:[^()]+|\([^)]+\))*)\)\s*;'
        for match in re.finditer(pattern2, combined):
            inst = Instance()
            inst.module_type = match.group(1) if match.group(1) else match.group(2)
            inst.instance_name = match.group(2) if match.group(1) else ""

            name = inst.module_type
            if name in ['assign', 'module', 'input', 'output', 'endmodule', 'powermodule', 'child1']:
                continue
            conn = match.group(3)
            for c in conn.split(','):
                c = c.strip()
                m = re.search(r'\.(\w+)\s*\(([^)]+)\)', c)
                if m:
                    inst.connections[m.group(1)] = m.group(2).strip()
            if inst.connections:
                module.instances.append(inst)

    def _extract_statements_from_range(self, header_content: str, body_end: int, module: Module):
        endpowermodule_pos = header_content.find('endpowermodule')
        if endpowermodule_pos == -1:
            endpowermodule_pos = body_end

        body_start = header_content.find('};')
        if body_start == -1:
            body_start = header_content.rfind('}')
        if body_start != -1:
            body_start += 1

        body = header_content[body_start:endpowermodule_pos]
        combined = ' '.join(body.split())
        assign_pattern = r'assign\s+(\w+)\s*=\s*(.+?);'
        for match in re.finditer(assign_pattern, combined):
            stmt = f"assign {match.group(1)} = {match.group(2)};"
            if stmt not in module.statements:
                module.statements.append(stmt)

    def _extract_statements(self, content: str, module: Module):
        combined = ' '.join(content.split())
        assign_pattern = r'assign\s+(\w+)\s*=\s*(.+?);'
        for match in re.finditer(assign_pattern, combined):
            stmt = f"assign {match.group(1)} = {match.group(2)};"
            if stmt not in module.statements:
                module.statements.append(stmt)


def test_parser():
    parser = PvParser()
    modules = parser.parse_file('/media/sf_shared/vscode_shared/project_power_verilog/examples/test_design.pv')

    for name, mod in modules.items():
        print(f"Module: {name}")
        print(f"  Is powermodule: {mod.is_powermodule}")
        print(f"  Supply ports: {mod.supply_ports}")
        print(f"  Ports: {[p.name for p in mod.ports]}")
        print(f"  Instances: {[i.module_name for i in mod.instances]}")
        print(f"  Statements: {mod.statements}")
        print()


if __name__ == '__main__':
    test_parser()