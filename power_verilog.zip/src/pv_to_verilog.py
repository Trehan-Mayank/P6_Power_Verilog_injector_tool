#!/usr/bin/env python3
"""
Main entry point for Power Verilog conversion.
Converts .pv files to standard Verilog.
"""

import argparse
import sys
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pv_parser import PvParser
from pv_restructurer import PvRestructurer
from corruption_injector import CorruptionEngine


def convert_pv_to_v(input_file: str, output_file: str = None, inject_corruption: bool = False):
    parser = PvParser()
    modules = parser.parse_file(input_file)

    if inject_corruption:
        engine = CorruptionEngine(modules)
        engine.inject_corruption()

    restructurer = PvRestructurer(modules)
    verilog_code = restructurer.generate_verilog()

    if output_file:
        with open(output_file, 'w') as f:
            f.write(verilog_code)
        print(f"Converted {input_file} -> {output_file}")
    else:
        print(verilog_code)

    return verilog_code


def main():
    parser = argparse.ArgumentParser(description='Convert Power Verilog (.pv) to standard Verilog')
    parser.add_argument('input', help='Input .pv file')
    parser.add_argument('-o', '--output', help='Output .v file (default: stdout)')
    parser.add_argument('--corrupt', action='store_true', help='Inject corruption logic')

    args = parser.parse_args()
    convert_pv_to_v(args.input, args.output, args.corrupt)


if __name__ == '__main__':
    main()