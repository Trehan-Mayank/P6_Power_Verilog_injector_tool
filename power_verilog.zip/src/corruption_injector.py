#!/usr/bin/env python3
"""
Corruption Engine
Injects corruption logic into RTL for power-aware simulation.
"""

import re
from typing import Dict, List, Tuple
from pv_parser import Module, Port


class CorruptionEngine:
    FULL_ON = "FULL_ON"
    POWER_GATED = "POWER_GATED"
    CORRUPTION_VALUE = "'x"

    def __init__(self, modules: Dict[str, Module]):
        self.modules = modules
        self.power_domains: Dict[str, List[str]] = {}
        self.mirrored_modules: Dict[str, str] = {}  # original_name -> new_name

    def inject_corruption(self) -> Dict[str, Module]:
        self._identify_power_domains()

        # Create mirrored modules for any module (powermodule or not) with different power connections
        self._create_all_mirrored_modules()

        modules_list = list(self.modules.items())
        for name, mod in modules_list:
            if mod.is_powermodule:
                self._corrupt_powermodule(mod)
            elif self._has_power_connections(name):
                self._create_mirrored_modules(mod)

        return self.modules

    def _create_all_mirrored_modules(self):
        # Find all modules that are instantiated with different power connections
        seen_combinations = {}  # (child_module_name, power_conn_key) -> mirrored_name

        # Create a list to avoid iteration issues when modifying dict
        parent_modules = [(n, m) for n, m in self.modules.items() if m.is_powermodule]

        for parent_name, parent_mod in parent_modules:
            if not parent_mod.is_powermodule:
                continue

            for inst in parent_mod.instances:
                child_mod_name = inst.module_type

                if child_mod_name not in self.modules:
                    continue

                if not inst.power_connections:
                    continue

                # Create a key from power connections
                pwr_key = tuple(sorted(inst.power_connections.items()))

                if (child_mod_name, pwr_key) not in seen_combinations:
                    # Need to create mirrored module
                    child_mod = self.modules[child_mod_name]
                    hash_suffix = abs(hash(child_mod_name + str(pwr_key))) % 10000
                    mirrored_name = f"{child_mod_name}_m{hash_suffix}"

                    if mirrored_name not in self.modules:
                        mirrored_mod = Module(
                            name=mirrored_name,
                            is_powermodule=False,
                            ports=child_mod.ports.copy(),
                            supply_ports=inst.power_connections.copy(),
                            instances=[],
                            statements=[]
                        )

                        for stmt in child_mod.statements:
                            corrupted = self._corrupt_statement_with_power(stmt, inst.power_connections)
                            mirrored_mod.statements.append(corrupted)

                        # Copy instances from original if any
                        mirrored_mod.instances = child_mod.instances.copy()

                        self.modules[mirrored_name] = mirrored_mod
                        seen_combinations[(child_mod_name, pwr_key)] = mirrored_name

                    # Update instance to use mirrored module
                    inst.module_type = mirrored_name

                else:
                    # Use existing mirrored module
                    inst.module_type = seen_combinations[(child_mod_name, pwr_key)]

    def _identify_power_domains(self):
        for name, mod in self.modules.items():
            if mod.is_powermodule:
                power_pins = [p for p in mod.ports if p.supply_type == 'power']
                for pp in power_pins:
                    if pp.name not in self.power_domains:
                        self.power_domains[pp.name] = []

                    for inst in mod.instances:
                        if pp.name in inst.power_connections:
                            inst_power_net = inst.power_connections[pp.name]
                            if inst_power_net not in self.power_domains[pp.name]:
                                self.power_domains[pp.name].append(inst_power_net)

    def _has_power_connections(self, mod_name: str) -> bool:
        for name, mod in self.modules.items():
            if mod.is_powermodule:
                for inst in mod.instances:
                    inferred_mod = self._get_module_type(inst.module_name)
                    if inferred_mod == mod_name and inst.power_connections:
                        return True
        return False

    def _get_module_type(self, instance_name: str) -> str:
        for mod_name in self.modules:
            if instance_name.startswith(mod_name) or instance_name == mod_name:
                return mod_name
        return instance_name

    def _create_mirrored_modules(self, mod: Module):
        instances_with_power = []
        for name, parent_mod in self.modules.items():
            if parent_mod.is_powermodule:
                for inst in parent_mod.instances:
                    inferred_mod = self._get_module_type(inst.module_name)
                    if inferred_mod == mod.name and inst.power_connections:
                        instances_with_power.append((name, inst))

        for parent_name, inst in instances_with_power:
            hash_suffix = abs(hash(inst.module_name + str(inst.power_connections))) % 10000
            mirrored_name = f"{mod.name}_m{hash_suffix}"

            if mirrored_name not in self.modules:
                mirrored_mod = Module(
                    name=mirrored_name,
                    is_powermodule=False,
                    ports=mod.ports.copy(),
                    supply_ports=mod.supply_ports.copy(),
                    instances=[],
                    statements=[]
                )

                for stmt in mod.statements:
                    corrupted = self._corrupt_statement_with_power(stmt, inst.power_connections)
                    mirrored_mod.statements.append(corrupted)

                self.modules[mirrored_name] = mirrored_mod
                self.mirrored_modules[f"{mod.name}_{inst.module_name}"] = mirrored_name

    def _corrupt_statement_with_power(self, stmt: str, power_conns: Dict[str, str]) -> str:
        assign_match = re.match(r'assign\s+(\w+)\s*=\s*(.+?);', stmt)
        if not assign_match:
            return stmt

        lhs = assign_match.group(1)
        rhs = assign_match.group(2).strip()

        # Skip feedthroughs
        if rhs == lhs:
            return stmt

        if power_conns:
            power_nets = [v for v in power_conns.keys() if v.startswith('VDD')]
            ground_nets = [v for v in power_conns.keys() if v.startswith('VSS')]

            if power_nets:
                power_cond = ' && '.join(power_nets)
                ground_cond = ' || '.join(ground_nets) if ground_nets else '1\'b0'
                return f"assign {lhs} = ({power_cond} && !({ground_cond})) ? {rhs} : {self.CORRUPTION_VALUE};"

        return stmt

    def get_mirrored_name(self, original: str, instance_name: str) -> str:
        key = f"{original}_{instance_name}"
        return self.mirrored_modules.get(key, original)

    def _corrupt_powermodule(self, mod: Module):
        corrupted_statements = []

        for stmt in mod.statements:
            corrupted_stmt = self._corrupt_statement(stmt, mod)
            corrupted_statements.append(corrupted_stmt)

        mod.statements = corrupted_statements

        for inst in mod.instances:
            if inst.power_connections and inst.module_type in self.modules:
                child_mod = self.modules[inst.module_type]
                if not child_mod.is_powermodule:
                    mirrored_name = self.get_mirrored_name(child_mod.name, inst.module_type)
                    inst.module_type = mirrored_name

    def _corrupt_statement(self, stmt: str, mod: Module) -> str:
        assign_match = re.match(r'assign\s+(\w+)\s*=\s*(.+?);', stmt)
        if not assign_match:
            return stmt

        lhs = assign_match.group(1)
        rhs = assign_match.group(2).strip()

        # Skip feedthroughs: simple identifier connections like "assign o = a;"
        # Check if RHS is just a single identifier with no operators
        if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', rhs):
            return stmt

        # Find power and ground ports
        power_ports = [p for p in mod.supply_ports if p.startswith('VDD')]
        ground_ports = [p for p in mod.supply_ports if p.startswith('VSS')]

        if power_ports and ground_ports:
            # Corruption: output = 'x when power off or ground on
            power_cond = ' && '.join([f"{p}" for p in power_ports])
            ground_cond = ' || '.join([f"{p}" for p in ground_ports])
            corrupted = f"assign {lhs} = ({power_cond} && !({ground_cond})) ? {rhs} : {self.CORRUPTION_VALUE};"

            # Use ifdef to select between original and corrupted
            # DISABLE_CORRUPTION = 1 -> normal, else -> corruption
            lines = []
            lines.append(f"`ifndef DISABLE_CORRUPTION")
            lines.append(f"    {corrupted}")
            lines.append(f"`else")
            lines.append(f"    assign {lhs} = {rhs};")
            lines.append(f"`endif")
            return '\n'.join(lines)

        return stmt

    def _signal_has_power_dependency(self, signal: str, mod: Module) -> bool:
        for inst in mod.instances:
            if signal in inst.connections.values():
                if inst.power_connections:
                    return True

        return True

    def generate_state_module(self) -> str:
        lines = []
        lines.append("module sim_state;")
        lines.append("    parameter SIM_STATE = 2'b00;")
        lines.append("    localparam FULL_ON = 2'b00;")
        lines.append("    localparam RETENTION = 2'b01;")
        lines.append("    localparam POWER_GATED = 2'b10;")
        lines.append("endmodule")
        return '\n'.join(lines)


class IsoCell:
    def __init__(self):
        self.isolation_cell_types = {
            'iso_cell': 'ISO_CELL',
            'power_switch': 'PWR_SWITCH'
        }

    def generate_isolation_cell(self, inst_type: str, connections: Dict[str, str]) -> str:
        lines = []

        if inst_type == 'iso_cell':
            in_signal = connections.get('in')
            out_signal = connections.get('out')
            iso_en = connections.get('iso_en')
            vdd = connections.get('VDD')
            vss = connections.get('VSS')

            lines.append(f"    assign {out_signal} = {iso_en} ? {in_signal} : 1'b0;")
            lines.append(f"    // Isolation cell powered by {vdd}/{vss}")

        elif inst_type == 'power_switch':
            in_signal = connections.get('in')
            out_signal = connections.get('out')
            iso_en = connections.get('iso_en')
            vdd1 = connections.get('VDD1')
            vss1 = connections.get('VSS1')
            vdd2 = connections.get('VDD2')
            vss2 = connections.get('VSS2')

            lines.append(f"    assign {out_signal} = {iso_en} ? {in_signal} : 1'bx;")
            lines.append(f"    // Power switch: {vdd1}/{vss1} -> {vdd2}/{vss2}")

        return '\n'.join(lines)


if __name__ == '__main__':
    from pv_parser import PvParser
    from pv_restructurer import PvRestructurer

    parser = PvParser()
    modules = parser.parse_file('/media/sf_shared/vscode_shared/project_power_verilog/examples/test_design.pv')

    engine = CorruptionEngine(modules)
    engine.inject_corruption()

    restructurer = PvRestructurer(modules)
    print(restructurer.generate_verilog())