#!/usr/bin/env python3
"""
Power Verilog Restructurer
Converts parsed .pv modules to standard Verilog with power awareness.
"""

import re
from typing import Dict, List
from pv_parser import Module, Instance, Port


class PvRestructurer:
    def __init__(self, modules: Dict[str, Module]):
        self.modules = modules

    def generate_verilog(self) -> str:
        used_modules = self._find_used_modules()
        power_signals = self._get_power_signals()

        output = []
        output.append("`timescale 1ns / 1ps\n")
        output.append("// Generated from .pv file")
        output.append("// Power-aware Verilog\n")
        output.append("// To enable corruption, uncomment the following line:\n")
        output.append("// `define DISABLE_CORRUPTION 0\n")

        output.append("\n// ============================================")
        output.append("// COPY BELOW INTO YOUR TESTBENCH")
        output.append("// ============================================\n")
        output.append("// Power signals (define in tb)")
        for sig in power_signals:
            output.append(f"// logic {sig};")
        output.append("\n// Domain control task (define in tb)")
        output.append("// Usage: domain(1, 2'b10); // value: 00=off, 10=pwr, 01=gnd, 11=both")
        output.append("// task domain(input int num, input bit [1:0] value);")
        output.append("//     if (num == 1) begin VDD = value[1]; VSS = value[0]; end")
        output.append("//     if (num == 2) begin VDD_1 = value[1]; VSS_1 = value[0]; end")
        output.append("// endtask\n")
        output.append("// ============================================\n")

        for name, mod in self.modules.items():
            if name in used_modules:
                output.extend(self._generate_module(mod))

        return '\n'.join(output)

    def _get_power_signals(self) -> List[str]:
        signals = set()
        for name, mod in self.modules.items():
            if mod.is_powermodule:
                for p_name in mod.supply_ports.keys():
                    if p_name.startswith('VDD') or p_name.startswith('VSS'):
                        signals.add(p_name)
        return sorted(signals)

    def _find_used_modules(self) -> set:
        used = set()
        instantiated = set()
        for name, mod in self.modules.items():
            for inst in mod.instances:
                instantiated.add(inst.module_type)
        for name in instantiated:
            self._collect_used(name, used)
        for name in list(used):
            self._collect_parents(name, used)
        return used

    def _collect_used(self, name: str, used: set):
        if name not in self.modules:
            return
        if name in used:
            return
        used.add(name)
        mod = self.modules[name]
        for inst in mod.instances:
            self._collect_used(inst.module_type, used)

    def _collect_parents(self, name: str, used: set):
        for mod_name, mod in self.modules.items():
            for inst in mod.instances:
                if inst.module_type == name and mod_name not in used:
                    used.add(mod_name)
                    self._collect_parents(mod_name, used)

    def _generate_module(self, mod: Module) -> List[str]:
        lines = []

        if mod.is_powermodule:
            lines.append(f"module {mod.name} (")

            port_names = {p.name for p in mod.ports}
            used_in_logic = set()
            for stmt in mod.statements:
                for name in port_names:
                    if name in stmt:
                        used_in_logic.add(name)
            used_in_instances = set()
            for inst in mod.instances:
                used_in_instances.update(inst.power_connections.values())
            port_decl = []
            for sup_name, sup_type in mod.supply_ports.items():
                if sup_name in port_names and (sup_name in used_in_logic or sup_name in used_in_instances or sup_name in ('VDD', 'VSS')):
                    port_decl.append(f"    input {sup_name}")

            # Then add RTL ports
            rtl_ports = [p for p in mod.ports if not p.is_supply]
            for p in rtl_ports:
                if p.direction == 'input':
                    port_decl.append(f"    input {p.name}")
                elif p.direction == 'output':
                    port_decl.append(f"    output {p.name}")

            lines.append(',\n'.join(port_decl))
            lines.append(");")
            lines.append("")

            lines.append("    // Supply port description: " + ", ".join([f"{k}->{v}" for k, v in mod.supply_ports.items()]))
            lines.append("")

            for stmt in mod.statements:
                lines.append(f"    {stmt}")
            lines.append("")

            for inst in mod.instances:
                lines.extend(self._generate_instance(inst))

            lines.append("endmodule")
        else:
            lines.append(f"module {mod.name} (")

            port_names = {p.name for p in mod.ports}
            used_in_logic = set()
            for stmt in mod.statements:
                for name in port_names:
                    if name in stmt:
                        used_in_logic.add(name)
            used_in_instances = set()
            for inst in mod.instances:
                used_in_instances.update(inst.power_connections.keys())

            port_decl = []
            for p in mod.ports:
                if p.direction == 'supply' or p.is_supply:
                    sup_name = p.name
                    if sup_name in used_in_logic or sup_name in used_in_instances or sup_name in ('VDD', 'VSS'):
                        port_decl.append(f"    input {sup_name}")
                elif p.direction == 'input':
                    port_decl.append(f"    input {p.name}")
                elif p.direction == 'output':
                    port_decl.append(f"    output {p.name}")

            lines.append(',\n'.join(port_decl))
            lines.append(");")
            lines.append("")

            if mod.supply_ports:
                lines.append("    // Supply port description: " + ", ".join([f"{k}->{v}" for k, v in mod.supply_ports.items()]))
                lines.append("")

            for stmt in mod.statements:
                if '? ' in stmt and ": 'x" in stmt and "assign " in stmt:
                    lines.append(f"    `ifndef DISABLE_CORRUPTION")
                    lines.append(f"    {stmt}")
                    lines.append(f"    `else")
                    match = re.match(r'assign\s+(\w+)\s*=\s*.+?\?\s*(.+?)\s*:\s*.+', stmt)
                    if match:
                        lhs = match.group(1)
                        rhs = match.group(2)
                        lines.append(f"    assign {lhs} = {rhs};")
                    lines.append(f"    `endif")
                else:
                    lines.append(f"    {stmt}")

            lines.append("endmodule")

        lines.append("")
        return lines

    def _generate_instance(self, inst: Instance) -> List[str]:
        lines = []

        # Filter out clamp from connections (it's a parameter, not port)
        filtered_conns = {k: v for k, v in inst.connections.items() if k != 'clamp'}

        # Power connections first
        inst_conns = []
        for p_port, p_net in inst.power_connections.items():
            inst_conns.append(f".{p_port}({p_net})")

        # Then RTL ports
        for port, net in filtered_conns.items():
            inst_conns.append(f".{port}({net})")

        if inst.instance_name:
            inst_name = inst.instance_name
        else:
            inst_name = inst.module_type

        lines.append(f"    {inst.module_type} #() {inst_name} (")

        # Add signal connections - comma after each except last
        for i, c in enumerate(inst_conns):
            if i < len(inst_conns) - 1:
                lines.append(f"        {c},")
            else:
                lines.append(f"        {c}")

        lines.append("    );")

        return lines

    def _generate_iso_cell(self, inst: Instance) -> List[str]:
        lines = []
        in_sig = inst.connections.get('in', '1\'b0')
        out_sig = inst.connections.get('out', 'open')
        iso_en = inst.connections.get('iso_en', '1\'b0')
        clamp_val = inst.connections.get('clamp', '1\'b0')
        vdd = inst.power_connections.get('VDD', 'VDD')
        vss = inst.power_connections.get('VSS', 'VSS')

        lines.append(f"    // ISO_CELL powered by {vdd}/{vss}")

        iso_name = f"iso_{out_sig}"
        pwr_on = f"{vdd}_on"
        gnd_on = f"{vss}_on"

        lines.append(f"    // Supply state: {vdd} ON && {vss} OFF")
        lines.append(f"    wire {iso_name}_supplies_on;")
        lines.append(f"    assign {iso_name}_supplies_on = ({pwr_on} && ~{gnd_on});")

        lines.append(f"    wire {iso_name}_out;")
        lines.append(f"    assign {iso_name}_out = (iso_en === 1'bx) ? 1'bx :")
        lines.append(f"                              ({iso_name}_supplies_on === 1'b0) ? 1'bx :")
        lines.append(f"                              (iso_en === 1'b1) ? {clamp_val} :")
        lines.append(f"                              {in_sig};")

        lines.append(f"    assign {out_sig} = {iso_name}_out;")

        return lines

    def _generate_power_switch(self, inst: Instance) -> List[str]:
        lines = []
        in_sig = inst.connections.get('in', '1\'b0')
        out_sig = inst.connections.get('out', 'open')
        iso_en = inst.connections.get('iso_en', '1\'b0')
        vdd1 = inst.power_connections.get('VDD1', 'VDD')
        vss1 = inst.power_connections.get('VSS1', 'VSS')
        vdd2 = inst.power_connections.get('VDD2', 'VDD_1')
        vss2 = inst.power_connections.get('VSS2', 'VSS_1')

        lines.append(f"    // POWER_SWITCH: {vdd1}/{vss1} -> {vdd2}/{vss2}")

        pwr_domain = f"PWR_{vdd2}_on"

        if iso_en != '1\'b1':
            lines.append(f"    wire {out_sig};")
            lines.append(f"    assign {out_sig} = {iso_en} ? {vdd2} : 1'bx;")
        else:
            lines.append(f"    wire {out_sig};")
            lines.append(f"    assign {out_sig} = {vdd2};")
        return lines


if __name__ == '__main__':
    from pv_parser import PvParser

    parser = PvParser()
    modules = parser.parse_file('/media/sf_shared/vscode_shared/project_power_verilog/examples/test_design.pv')

    restructurer = PvRestructurer(modules)
    print(restructurer.generate_verilog())