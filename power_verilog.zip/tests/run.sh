#!/bin/bash

cd /media/sf_shared/vscode_shared/project_power_verilog/tests

echo "=== Compiling tb_power_mirror.sv ==="
iverilog -g2005-sv -o tb_power_mirror tb_power_mirror.sv 2>&1

if [ $? -eq 0 ]; then
    echo "=== Compilation successful ==="
    echo "=== Running simulation ==="
    vvp tb_power_mirror
else
    echo "=== Compilation failed ==="
    exit 1
fi