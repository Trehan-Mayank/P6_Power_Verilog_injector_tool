`timescale 1ns / 1ps
`include "simple_and.v"

module tb_and_gate;

reg VDD, VSS;
reg VDD_child, VSS_child;
reg a, b;
wire o;

and_gate_top dut (
    .VDD(VDD),
    .VSS(VSS),
    .VDD_child(VDD_child),
    .VSS_child(VSS_child),
    .a(a),
    .b(b),
    .o(o)
);

initial begin
    $display("=== Testing Corruption Logic ===");
    $display("");

    VDD = 1; VSS = 0;
    VDD_child = 1; VSS_child = 0;
    a = 0; b = 0;
    #10;
    $display("Test 1: a=0 b=0 -> o=%b (expect: 0)", o);

    a = 0; b = 1;
    #10;
    $display("Test 2: a=0 b=1 -> o=%b (expect: 0)", o);

    a = 1; b = 0;
    #10;
    $display("Test 3: a=1 b=0 -> o=%b (expect: 0)", o);

    a = 1; b = 1;
    #10;
    $display("Test 4: a=1 b=1 -> o=%b (expect: 1)", o);

    $display("");
    $display("=== Testing Power Off (Corruption) ===");
    $display("");

    VDD_child = 0; VSS_child = 0;
    a = 1; b = 1;
    #10;
    $display("Test 5: Power OFF VDD_child=0 VSS_child=0 a=1 b=1 -> o=%b (expect: x)", o);

    VDD_child = 1; VSS_child = 1;
    a = 1; b = 1;
    #10;
    $display("Test 6: Ground ON VDD_child=1 VSS_child=1 a=1 b=1 -> o=%b (expect: x)", o);

    $display("");
    $display("=== All tests completed ===");
    $finish;
end

endmodule