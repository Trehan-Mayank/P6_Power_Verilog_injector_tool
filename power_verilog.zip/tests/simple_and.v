`timescale 1ns / 1ps

// Generated from .pv file
// Power-aware Verilog

// To enable corruption, uncomment the following line:

// `define DISABLE_CORRUPTION 0

module and_gate_top (
    input VDD,
    input VSS,
    input VDD_child,
    input VSS_child,
    input a,
    input b,
    output o
);

    // Supply port description: VDD->main_power, VSS->main_ground, VDD_child->power, VSS_child->ground


    and2_m9529 #() and2 (
        .VDD(VDD_child),
        .VSS(VSS_child),
        .a(a),
        .b(b),
        .o(o)
    );
endmodule

module and2_m9529 (
    input VDD,
    input VSS,
    input a,
    input b,
    output o,
    input VDD_child,
    input VSS_child
);

    // Supply port description: VDD->VDD_child, VSS->VSS_child

    `ifndef DISABLE_CORRUPTION
    assign o = (VDD && !(VSS)) ? a & b : 'x;
    `else
    assign o = a & b;
    `endif
endmodule
