`timescale 1ns / 1ps
`include "power_test_mirror.v"

module tb;
    reg a1, b1, a2, b2;
    reg VDD, VSS, VDD_1, VSS_1;
    wire o1, o2;

    // Helper: set power domains
    // D1=[3:2], D2=[1:0] -> format: {VDD,VSS,VDD_1,VSS_1}
    task set_power;
        input [1:0] d1_pwr;  // Domain1: {VDD, VSS}
        input [1:0] d2_pwr;  // Domain2: {VDD_1, VSS_1}
        begin
            VDD   = d1_pwr[1];
            VSS   = d1_pwr[0];
            VDD_1 = d2_pwr[1];
            VSS_1 = d2_pwr[0];
        end
    endtask

    top u_top (
        .VDD(VDD),
        .VSS(VSS),
        .VDD_1(VDD_1),
        .VSS_1(VSS_1),
        .a1(a1),
        .b1(b1),
        .a2(a2),
        .b2(b2),
        .o1(o1),
        .o2(o2)
    );

    initial begin
        $display("=== Power-Aware Simulation Test ===");

        // Initialize - all off
        set_power(2'b00, 2'b00);
        a1 = 0; b1 = 0; a2 = 0; b2 = 0;
        #10;

        $display("Test 1: Both OFF");
        $display("  o1=%b o2=%b (expect: x x)", o1, o2);

        // Domain 1 ON
        set_power(2'b10, 2'b00);  // VDD=1, VSS=0
        #10;
        $display("Test 2: Domain1 ON");
        $display("  o1=%b o2=%b (expect: x x)", o1, o2);

        // Both ON
        set_power(2'b10, 2'b10);  // VDD=1, VSS=0, VDD_1=1, VSS_1=0
        #10;
        $display("Test 3: Both ON (inputs=0)");
        $display("  o1=%b o2=%b (expect: 0 0)", o1, o2);

        // Apply inputs
        a1 = 1; b1 = 1;
        a2 = 1; b2 = 1;
        #10;
        $display("Test 4: Inputs=1, both ON");
        $display("  o1=%b o2=%b (expect: 1 1)", o1, o2);

        // Turn off domain 1
        set_power(2'b00, 2'b10);
        #10;
        $display("Test 5: Domain1 OFF");
        $display("  o1=%b o2=%b (expect: x 1)", o1, o2);

        // Turn off domain 2
        set_power(2'b00, 2'b00);
        #10;
        $display("Test 6: Both OFF");
        $display("  o1=%b o2=%b (expect: x x)", o1, o2);

        // Test with inputs
        set_power(2'b10, 2'b10);
        a1 = 1; b1 = 1; a2 = 1; b2 = 1;
        #10;
        $display("Test 7: Both ON");
        $display("  o1=%b o2=%b (expect: 1 1)", o1, o2);

        // Ground ON test
        set_power(2'b11, 2'b10);  // VDD=1, VSS=1 (ground on)
        #10;
        $display("Test 8: Domain1 Ground ON");
        $display("  o1=%b o2=%b (expect: x 1)", o1, o2);

        $display("=== Tests Complete ===");
        $finish;
    end
endmodule