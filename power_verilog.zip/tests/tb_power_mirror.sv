`timescale 1ns / 1ps
`include "power_test_mirror.v"

module tb;
    // Power signals
    logic VDD, VSS, VDD_1, VSS_1;

    logic a1, b1, a2, b2;
    wire o1, o2;

    // Domain control - defined inside tb
    // Usage: domain(1, 2'b10);
    // value: 00=off, 10=pwr, 01=gnd, 11=both
    task domain(input int num, input bit [1:0] value);
        if (num == 1) begin VDD = value[1]; VSS = value[0]; end
        if (num == 2) begin VDD_1 = value[1]; VSS_1 = value[0]; end
    endtask

    top u_top (
        .VDD(VDD), .VSS(VSS),
        .VDD_1(VDD_1), .VSS_1(VSS_1),
        .a1(a1), .b1(b1),
        .a2(a2), .b2(b2),
        .o1(o1), .o2(o2)
    );

    initial begin
        $display("=== Power Test ===");

        domain(1, 2'b00);
        domain(2, 2'b00);
        a1=0; b1=0; a2=0; b2=0;
        #10;
        $display("Both OFF: o1=%b o2=%b", o1, o2);

        domain(1, 2'b10);
        #10;
        $display("D1 ON: o1=%b o2=%b", o1, o2);

        domain(1, 2'b10);
        domain(2, 2'b10);
        a1=1; b1=1; a2=1; b2=1;
        #10;
        $display("Both ON: o1=%b o2=%b", o1, o2);

        domain(1, 2'b00);
        #10;
        $display("D1 OFF: o1=%b o2=%b", o1, o2);

        domain(1, 2'b01);
        #10;
        $display("D1 Ground: o1=%b o2=%b", o1, o2);

        $display("=== Done ===");
        $finish;
    end
endmodule